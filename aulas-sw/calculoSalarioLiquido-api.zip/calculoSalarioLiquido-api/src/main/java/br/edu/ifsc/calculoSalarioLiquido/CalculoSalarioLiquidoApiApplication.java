package br.edu.ifsc.calculoSalarioLiquido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculoSalarioLiquidoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculoSalarioLiquidoApiApplication.class, args);
	}

}
