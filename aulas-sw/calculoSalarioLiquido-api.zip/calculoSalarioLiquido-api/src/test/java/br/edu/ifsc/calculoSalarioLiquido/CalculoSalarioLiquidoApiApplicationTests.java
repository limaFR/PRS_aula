package br.edu.ifsc.calculoSalarioLiquido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculoSalarioLiquidoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
